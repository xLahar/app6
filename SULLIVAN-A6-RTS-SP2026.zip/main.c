/*
Author: Logan Sullivan
EEE 4775 RTS Spring 2026
Application 6
Theme: Theme Park Systems

Velocity Kingdom Ride Control Prototype
Ride: Thunder Vortex

This real-time system simulates ride safety control using
FreeRTOS tasks, an emergency stop ISR, sensor monitoring,
and timed brake activation.
*/

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "driver/adc.h"

#define RUN_LED GPIO_NUM_18
#define BRAKE_LED GPIO_NUM_19
#define HEARTBEAT_LED GPIO_NUM_21
#define ESTOP_BUTTON GPIO_NUM_4
#define POTENTIOMETER GPIO_NUM_34

// Queue used to pass ride position sensor data
QueueHandle_t sensorQueue;

// Mutex protects shared brake LED control
SemaphoreHandle_t brakeMutex;

// Semaphore used to signal E-stop event from ISR
SemaphoreHandle_t estopSemaphore;

// Global flag for emergency stop state
volatile bool emergencyStop = false;

// Emergency stop button interrupt
// Immediately signals control task
void IRAM_ATTR estop_isr_handler(void *arg) {
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    emergencyStop = true;
    xSemaphoreGiveFromISR(estopSemaphore, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

// Reads ride position from potentiometer every 500 ms
// Sends data to brake control task
void sensorTask(void *pvParameters) {
    int sensorValue;

    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(ADC1_CHANNEL_6, ADC_ATTEN_DB_11);

    while (1) {
        sensorValue = adc1_get_raw(ADC1_CHANNEL_6);

        xQueueSend(sensorQueue, &sensorValue, portMAX_DELAY);

        printf("[%lld ms] Thunder Vortex track position: %d\n",
               esp_timer_get_time() / 1000,
               sensorValue);

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

// Applies brakes if ride enters danger zone
// or if emergency stop is active
void brakeTask(void *pvParameters) {
    int distance;

    while (1) {
        if (xQueueReceive(sensorQueue, &distance, portMAX_DELAY)) {

            xSemaphoreTake(brakeMutex, portMAX_DELAY);

            if (distance < 600 || emergencyStop) {
                gpio_set_level(BRAKE_LED, 1);
                gpio_set_level(RUN_LED, 0);

                printf("[%lld ms] Thunder Vortex magnetic brakes ENGAGED\n",
                       esp_timer_get_time() / 1000);
            } else {
                gpio_set_level(BRAKE_LED, 0);
                gpio_set_level(RUN_LED, 1);
            }

            xSemaphoreGive(brakeMutex);
        }
    }
}

// Simulates station-side operations
// Uses variable execution time (soft real-time)
void passengerLoadTask(void *pvParameters) {
    while (1) {
        printf("[%lld ms] Thunder Vortex station operations task running...\n",
               esp_timer_get_time() / 1000);

        vTaskDelay(pdMS_TO_TICKS(200 + (esp_timer_get_time() % 300)));
    }
}

// Blinks status LED once per second
// Used to prove deterministic scheduling
void heartbeatTask(void *pvParameters) {
    while (1) {
        gpio_set_level(HEARTBEAT_LED, 1);
        vTaskDelay(pdMS_TO_TICKS(100));
        gpio_set_level(HEARTBEAT_LED, 0);
        vTaskDelay(pdMS_TO_TICKS(900));
    }
}

// Handles emergency stop events from ISR
// Pauses ride for 2 seconds before resume
void estopTask(void *pvParameters) {
    while (1) {
        if (xSemaphoreTake(estopSemaphore, portMAX_DELAY)) {
            printf("[%lld ms] CONTROL ALERT: Thunder Vortex emergency stop activated\n",
                   esp_timer_get_time() / 1000);

            gpio_set_level(BRAKE_LED, 1);
            gpio_set_level(RUN_LED, 0);

            vTaskDelay(pdMS_TO_TICKS(2000));
            emergencyStop = false;

            printf("[%lld ms] Thunder Vortex resumed\n",
                   esp_timer_get_time() / 1000);
        }
    }
}

// Initializes GPIO, synchronization objects,
// and starts all RTOS tasks
void app_main() {
    gpio_set_direction(RUN_LED, GPIO_MODE_OUTPUT);
    gpio_set_direction(BRAKE_LED, GPIO_MODE_OUTPUT);
    gpio_set_direction(HEARTBEAT_LED, GPIO_MODE_OUTPUT);

    gpio_set_level(RUN_LED, 0);
    gpio_set_level(BRAKE_LED, 0);
    gpio_set_level(HEARTBEAT_LED, 0);

    gpio_set_direction(ESTOP_BUTTON, GPIO_MODE_INPUT);
    gpio_set_pull_mode(ESTOP_BUTTON, GPIO_PULLUP_ONLY);

    gpio_set_intr_type(ESTOP_BUTTON, GPIO_INTR_NEGEDGE);
    gpio_install_isr_service(0);
    gpio_isr_handler_add(ESTOP_BUTTON, estop_isr_handler, NULL);

    sensorQueue = xQueueCreate(5, sizeof(int));
    brakeMutex = xSemaphoreCreateMutex();
    estopSemaphore = xSemaphoreCreateBinary();

    printf("\n=== Velocity Kingdom Ride Control System ===\n");
    printf("Initializing Thunder Vortex...\n");
    printf("Safety systems online\n");
    printf("RTOS scheduler started\n\n");

    xTaskCreate(sensorTask, "Sensor Task", 2048, NULL, 3, NULL);
    xTaskCreate(brakeTask, "Brake Task", 2048, NULL, 4, NULL);
    xTaskCreate(passengerLoadTask, "Passenger Load", 2048, NULL, 1, NULL);
    xTaskCreate(heartbeatTask, "Heartbeat", 2048, NULL, 2, NULL);
    xTaskCreate(estopTask, "EStop Task", 2048, NULL, 5, NULL);
}